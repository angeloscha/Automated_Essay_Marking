from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import numpy as np
import tensorflow as tf

from second_word_2_vector import *

tf.logging.set_verbosity(tf.logging.INFO)


def cnn_model_fn(features, labels, mode):

	input_layer = tf.reshape(features["x"], [-1, 676, 300])

	conv1 = tf.layers.conv1d(
		inputs=input_layer,
		filters=300,
		kernel_size=3,
		padding="same",
		activation=tf.nn.sigmoid)

	pool1 = tf.layers.max_pooling1d(inputs=conv1, pool_size=5, strides=2)

	conv2 = tf.layers.conv1d(
		inputs=pool1,
		filters=600,
		kernel_size=3,
		padding="same",
		activation=tf.nn.sigmoid)

	pool2 = tf.layers.max_pooling1d(inputs=conv2, pool_size=5, strides=2)

	pool2_flat = tf.reshape(pool2, [-1, 166*600]) 

	dense = tf.layers.dense(inputs=pool2_flat, units=1024, activation=tf.nn.sigmoid)


	logits = tf.layers.dense(inputs=dense, units=6)

	predictions = {
		"classes": tf.argmax(input=logits, axis=1),
		"probabilities": tf.nn.softmax(logits, name="softmax_tensor")
	}


	if mode == tf.estimator.ModeKeys.PREDICT:
		return tf.estimator.EstimatorSpec(mode=mode, predictions=predictions)

	onehot_labels = tf.one_hot(indices=tf.cast(labels, tf.int32), depth=6)
	loss = tf.losses.softmax_cross_entropy(onehot_labels=onehot_labels, logits =logits)
	
	if mode == tf.estimator.ModeKeys.TRAIN:
		optimizer = tf.train.GradientDescentOptimizer(learning_rate=0.001)
		train_op = optimizer.minimize(
			loss=loss,
			global_step=tf.train.get_global_step())
		return tf.estimator.EstimatorSpec(mode=mode, loss=loss, train_op=train_op)

	eval_metric_ops = {
		"accuracy": tf.metrics.accuracy(
			labels=labels, predictions=predictions["classes"])
		}
	return tf.estimator.EstimatorSpec(
		mode=mode, loss=loss, eval_metric_ops=eval_metric_ops)


def main(unused_argv):
	train_data = train_essays_1
	train_labels = train_labels_1
	eval_data = eval_essays_1
	eval_labels = eval_labels_1


	project_classifier = tf.estimator.Estimator(
		model_fn=cnn_model_fn, model_dir='cnn_model4.0')



	tensors_to_log = {"probabilities": "softmax_tensor"}
	logging_hook = tf.train.LoggingTensorHook(
		tensors=tensors_to_log, every_n_iter=50)

	train_input_fn = tf.estimator.inputs.numpy_input_fn(
		x={"x": train_data},
		y=train_labels,
		num_epochs=None,
		shuffle=True)

	project_classifier.train(
		input_fn=train_input_fn,
		steps=20000,
		hooks=[logging_hook])

	eval_input_fn = tf.estimator.inputs.numpy_input_fn(
		x={"x": eval_data},
		y=eval_labels,
		num_epochs=1,
		shuffle=False)
	
	eval_results = project_classifier.evaluate(input_fn=eval_input_fn)

	print(eval_results)

	predictions_input_fn = tf.estimator.inputs.numpy_input_fn(
		x={"x": eval_data},
		y=None,
		shuffle=False)

	predictions = project_classifier.predict(
    	input_fn=eval_input_fn,
	)	


	l_predictionss = list(predictions)
	predictionss = []
	for pred in l_predictionss:
		predictionss = np.append(predictionss,pred['classes'])

	confusion_matrix = tf.contrib.metrics.confusion_matrix(eval_labels, predictionss)
	with tf.Session() as sess:
	    print(sess.run(confusion_matrix))



if __name__ == "__main__":
  tf.app.run()
