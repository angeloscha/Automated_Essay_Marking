In order to run each version:

1. Download the Google News pre-trained model bin file(link in Google News Pre-Trained Model Link txt file)
2. Copy the model bin file and the training_set_rel3 tsv file into the version's folder
3. Run the conv_neural_network.py file using python