import csv
import itertools

with open ('training_set_rel3.tsv','r',encoding="cp1252") as tsvfile:
	reader = csv.reader(tsvfile, delimiter='\t')
	columns_section = itertools.islice(reader, 0, 1)
	columns = ""

	essay_section = itertools.islice(reader, 0, 1750)
	list_of_essays_labels = []
	list_of_essays = []
	list_of_labels = []


	for row in columns_section:
		temp = str(row)

	columns = temp.strip().split(',')

	rem = "[]\' "
	temp= "" 
	for i in range(len(columns)):
		for y in range(len(columns[i])):
			if columns[i][y] not in rem:
				temp=temp+columns[i][y]
		columns[i]=temp
		temp = ""


	for row in essay_section:
		list_of_essays_labels.append(row)

	yy=[2,6]

	for i in range(len(list_of_essays_labels)):
		for y in reversed(range(len(list_of_essays_labels[i]))):
			if y not in yy:
				del list_of_essays_labels[i][y]




for i in range(len(list_of_essays_labels)):
	list_of_essays.append(list_of_essays_labels[i][0])
	list_of_labels.append(list_of_essays_labels[i][1])

marks =[]
training_list_of_essays = []
training_list_of_labels = []
evaluation_list_of_essays = []
evaluation_list_of_labels = []

groups=[[["2","3","4","5"],35,"0"], [["6","7"],150,"1"], [["8"],150,"2"],[["9"],150,"3"],[["10"],150,"4"],[["11","12"],80,"5"]]


for i in range(len(list_of_labels)):
	for y in range(len(groups)):
		if list_of_labels[i] in groups[y][0] and training_list_of_labels.count(groups[y][2])<groups[y][1]:
			training_list_of_essays.append(list_of_essays[i])
			training_list_of_labels.append(groups[y][2])		
		elif list_of_labels[i] in groups[y][0]:
			evaluation_list_of_essays.append(list_of_essays[i])
			evaluation_list_of_labels.append(groups[y][2])	