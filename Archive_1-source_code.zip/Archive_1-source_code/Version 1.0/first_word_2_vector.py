import logging
logging.basicConfig(format='%(asctime)s : %(levelname)s : %(message)s', level=logging.INFO)
from gensim import corpora
from collections import defaultdict
import numpy as np

from dataset_preprocessing import *


def wordlist_to_vectorlist(lista):
	documents = []
	for i in range(len(lista)):
		documents.append(lista[i])


	texts = [[word for word in document.lower().split()]
	        for document in documents]

	frequency = defaultdict(int)
	for text in texts:
		for token in text:
			frequency[token] += 1
	texts = [[token for token in text if frequency[token] > 1]
			for text in texts]



	dictionary = corpora.Dictionary(texts)
	dictionary.save('/tmp/deerwester.dict')

	corpus = [dictionary.doc2bow(text) for text in texts]
	corpora.MmCorpus.serialize('deerwester.mm', corpus)

	return {'corpus':corpus, 'dictionary':dictionary}


def new_wordlist_to_vectorlist(string, dictionary):
	new_doc = string
	new_vec = dictionary.doc2bow(new_doc.lower().split())
	return new_vec


res = wordlist_to_vectorlist(list_of_essays)
train_essays_1 = []
eval_essays_1 = []
for i in range(len(training_list_of_essays)):
	ress = new_wordlist_to_vectorlist(training_list_of_essays[i], res['dictionary'])
	train_essays_1.append(ress)
	
for i in range(len(evaluation_list_of_essays)):
	ress = new_wordlist_to_vectorlist(evaluation_list_of_essays[i], res['dictionary'])
	eval_essays_1.append(ress)



max_len = 363
for i in range(len(train_essays_1)):
	if len(train_essays_1[i])>max_len:
		max_len = len(train_essays_1[i])

for i in range(len(train_essays_1)):
	while len(train_essays_1[i])<max_len:
		train_essays_1[i].append((0,0))


for i in range(len(eval_essays_1)):
	if len(eval_essays_1[i])>max_len:
		max_len = len(eval_essays_1[i])

for i in range(len(eval_essays_1)):
	while len(eval_essays_1[i])<max_len:
		eval_essays_1[i].append((0,0))




train_essays_1 = np.asarray(train_essays_1,dtype=np.float32)
eval_essays_1 = np.asarray(eval_essays_1,dtype=np.float32)
train_labels_1 = np.asarray(training_list_of_labels,dtype=np.int32)
eval_labels_1 = np.asarray(evaluation_list_of_labels,dtype=np.int32)
