from dataset_preprocessing import *
import gensim 
import numpy as np

model = gensim.models.KeyedVectors.load_word2vec_format("GoogleNews-vectors-negative300.bin", binary=True)  


def split_list_of_essays(list_of_essayss):
	list_of_essays_splitted=[]
	for i in range(len(list_of_essayss)):
		list_of_essays_splitted.append(list_of_essayss[i].lower().split())
	return list_of_essays_splitted

def padding(list_of_essays_in_bow):
	max_len = 676 
	for i in range(len(list_of_essays_in_bow)):
		if len(list_of_essays_in_bow[i])>max_len:
			max_len = len(list_of_essays_in_bow[i])

	for i in range(len(list_of_essays_in_bow)):
		while len(list_of_essays_in_bow[i])<max_len:
			list_of_essays_in_bow[i].append([0]*300)
	return list_of_essays_in_bow


def list_of_essays_to_bow(list_of_essayss):
	list_of_essays_in_bow = []
	list_of_essays_splitted = split_list_of_essays(list_of_essayss)
	for i in range(len(list_of_essays_splitted)):
		list_of_essays_in_bow_single=[]
		for y in range(len(list_of_essays_splitted[i])):
			temp = "" 
			for z in range(len(list_of_essays_splitted[i][y])):
				if (list_of_essays_splitted[i][y][z]) not in ".,-+=!@#$%^&*()":
					temp+= list_of_essays_splitted[i][y][z]
			if temp in model:
				list_of_essays_in_bow_single.append(model.word_vec(temp))
		list_of_essays_in_bow.append(list_of_essays_in_bow_single)
		list_of_essays_in_bow = padding(list_of_essays_in_bow)
	return list_of_essays_in_bow


train_essays_1 = list_of_essays_to_bow(training_list_of_essays)
eval_essays_1 = list_of_essays_to_bow(evaluation_list_of_essays)


train_essays_1 = np.asarray(train_essays_1,dtype=np.float32)
eval_essays_1 = np.asarray(eval_essays_1,dtype=np.float32)
train_labels_1 = np.asarray(training_list_of_labels,dtype=np.int32)
eval_labels_1 = np.asarray(evaluation_list_of_labels,dtype=np.int32)
